

package com.example.demo.controller;


import com.example.demo.entity.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@RequestMapping("/demo")
public class Demo {

    @GetMapping("/getcode")
    @ResponseBody
    public String getCode(@RequestParam String client_id,@RequestParam String redirect_uri,@RequestParam String response_type,@RequestParam String scope,@RequestParam String state,HttpServletResponse response) throws IOException {

//        response.sendRedirect("https://www.baidu.com?code=0987654321&state=test");
        return "111";
    }

    @PostMapping("/access_token")
    @ResponseBody
    public Token getToken(@RequestBody GetDemoToken getDemoToken) {
        Token token = new Token();
        token.setAccess_token("OezXcEiiBSKSxW0eoylIeAsR0GmYd1awCffdHgb4fhS_KKf2CotGj2cBNUKQQvj-G0ZWEE5");
        token.setExpires_in("3600");
        token.setRefresh_token("OezXcEiiBSKSxW0eoylIeAsR0GmYd1awCffdHgb4fhS_KKf2CotGj2cBNUKQQvj-G0ZWEE5");
        token.setToken_type("brearer");
        return token;
    }

    @GetMapping("/getUser")
    @ResponseBody
    public User getUser(@RequestParam("access_token") String access_token) {

        User user = new User();
        user.setUserId("R0GmYd1awCffdHgb4fhS_KKf2CotGj2cBNUKQQvj-G0ZWEE5");
        user.setUsername("小张");
        user.setValue("1");
        return user;
    }



}
