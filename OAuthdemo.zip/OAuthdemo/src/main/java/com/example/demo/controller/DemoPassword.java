package com.example.demo.controller;

import com.example.demo.entity.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@RequestMapping("/demoPassword")
public class DemoPassword {

    @RequestMapping(value = "/authorize",method = RequestMethod.GET)
    public String getCode1(@RequestParam String response_type,@RequestParam String client_id ,@RequestParam String redirect_uri ,@RequestParam String scope ,HttpServletResponse response) throws IOException {

        return "test";

    }

    @RequestMapping(value = "/authorize1",method = RequestMethod.GET)
    public void getCode(@RequestParam String userName,@RequestParam String password ,HttpServletResponse response) throws IOException {

        response.sendRedirect("https://www.baidu.com?#access_token=iBSKSxW0eoylIeAsR0GmYd1awCffdHgb4fhS_KKf2CotGj2cB&expires_in=3600");

    }

    @GetMapping("/getUser")
    @ResponseBody
    public User getUser(@RequestParam("access_token") String access_token) {

        User user = new User();
        user.setUserId("R0GmYd1awCffdHgb4fhS_KKf2CotGj2cBNUKQQvj-G0ZWEE5");
        user.setUsername("小张");
        user.setValue("1");
        return user;
    }


}
